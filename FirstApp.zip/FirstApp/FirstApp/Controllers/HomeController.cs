﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirstApp.Models;
using FirstApp.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FirstApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            #region ViewData,ViewBag,TempData
            //ViewBag.Name = "Zaur";
            //TempData["Surname"] = "Necefli";
            //ViewData["Name"] = "Zaur";
            //return RedirectToAction("Index", "About");
            #endregion

            List<Student> students = new List<Student>
            {
                new Student{Id=1,Name="Ilkin",Surname="Aghayev"},
                new Student{Id=2,Name="Nigar",Surname="Kamran"},
                new Student{Id=3,Name="Reshad",Surname="Xan"},
                new Student{Id=4,Name="Rufet",Surname="Internetsiz"}
            };

            List<int> intList = new List<int> { 1, 2, 3, 4, 5 };
            string bestStudent = "Ayshen";

            HomeVM homeVM = new HomeVM
            {
                Students = students,
                Numbers = intList,
                BestStudent= bestStudent
            };
            return View(homeVM);
        }


    }
}