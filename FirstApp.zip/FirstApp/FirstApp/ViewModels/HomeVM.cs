﻿using FirstApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstApp.ViewModels
{
    public class HomeVM
    {
        public List<Student> Students { get; set; }
        public List<int> Numbers { get; set; }
        public string BestStudent { get; set; }
    }
}
